from django.db import models

class xyz(models.Manager):
    pass

