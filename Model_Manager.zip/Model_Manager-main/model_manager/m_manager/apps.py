from django.apps import AppConfig


class MManagerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'm_manager'
